nome = input ("Digite seu nome:")
idade = int (input("Digite sua idade"))
altura =  float(input("digite sua altura"))
peso = str (input("digite seu peso"))

print 